from flask import Blueprint, render_template, request, flash, jsonify
from flask_login import login_required, current_user
import mlmodel as m


views = Blueprint('views', __name__)


@views.route('/home', methods=['GET', 'POST'])
@login_required
def home():
    return render_template("home.html", user=current_user)

@views.route('/')
def wel():
    return render_template("welcome.html", user = current_user)




@views.route("/submit", methods = ['GET','POST'])
def sub():
    #here we took data from html -> python
    if request.method == "POST":
        #name = request.form["username"]

        sym1 = request.form["symp1"]
        sym2 = request.form["symp2"]
        sym3 = request.form["symp3"]
        sym4 = request.form["symp4"]
        sym5 = request.form["symp5"]

        disease_pred = m.pred(sym1,sym2,sym3,sym4,sym5)
        pd = disease_pred


    #here we took data from  python -> html
    return render_template("home.html", result = pd,user = current_user)

    